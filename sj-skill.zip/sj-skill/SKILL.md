---
name: sj-skill
description: "SJFOOD 3.0（HIFOOD 1.0 PRD）ERP 系統的 API 調用技能。This skill should be used when 需要查詢或操作 SJFOOD/世紀食品 ERP 數據，包括：銷售價目查詢（SD080 價錢表）、出貨記錄（SD170）、客戶發票、物料價格、預售資料、客戶評論等。涵蓋登入認證（取 SJToken JWT）、/api/Price/*、/api/ShipmentHistory/*、/api/Sd170ShipmentHistory/*、/api/SD290_Credit/* 等端點的調用方法、參數規則（SAP 物料號 18 位補零、客戶號 10 位補零）與回應解析。觸發詞：SJFOOD、HIFOOD、價錢表、出貨記錄、SD080、SD170、sjfood api。"
agent_created: true
---

# SJ-SKILL — SJFOOD 3.0 API 調用技能

基於 HIFOOD 1.0 PRD v2026.1.1.57 反編譯整理 + 生產環境實測驗證。

## 核心信息

- **API Base URL**：`https://api-sjfood3.sjfood.us`
- **認證**：JWT Bearer Token（HS256），有效期約 3~4 天，過期重新登入
- **回應格式**：JSON，**欄位為小寫/camelCase**（與 C# DTO 的 PascalCase 不同）

## 快速開始

使用 `scripts/sjfood_client.py`（已封裝認證與常用查詢）：

```bash
python scripts/sjfood_client.py login <賬號> <密碼>
python scripts/sjfood_client.py price --material 40052897 --plant 1800
python scripts/sjfood_client.py shipments --customer 108716 --date 2026-08-04
python scripts/sjfood_client.py invoice-items --vbeln 0500164755 --fkdat 2026-08-04
```

或在代碼中引用 `SJFoodClient` 類（見腳本內 docstring）。**嚴禁將賬號密碼硬編碼或寫入任何文件**；優先從環境變量 `SJFOOD_USER` / `SJFOOD_PASS` 讀取，缺失時向用戶詢問。

## 認證流程（兩步）

1. `POST /api/De020_Login/Login`，Body `{"username","password","Comments":""}` → 返回 `{"token","expiration"}`
2. 之後所有請求帶 Header：`Authorization: Bearer <token>`

JWT payload 含 `Username`、`DepartmentName`、`SalesGroup`（權限依據）、`iss=core`、`aud=SJFOOD_3.Api`。

## 關鍵參數規則（實測踩坑總結，務必遵守）

1. **SAP 物料號（MATNR）**：`Material` 參數必須 **18 位補零**（`000000000040052897`）；短號（`40052897`）請用 `SearchKey`
2. **SAP 客戶號（KUNNR）**：`CustomerId(s)` 必須 **10 位補零**（`0000108716`）；短號返回 200 但 0 筆，**不報錯**
3. **發票行號（POSNR）跳號**：迭代行項目時遇空行不能立即停止，建議連續 8 個空號才結束（實測 000030 空缺、000040 有數據）
4. **回應信封不統一**：`/api/Price/*` 用 `{data}`；`/api/ShipmentHistory/*` 用 `{list}`；`GetHistoryShipmentsRecord` 用 `{resultCode,resultMsg,resultData}`；`/api/SD290_Credit/*` 用 `{code,message,data}`
5. 多值參數用重複 query key：`&Plants=1800&Plants=100A`；`SearchKey` 需 URL Encode（UTF-8）
6. 價目數據有服務端緩存，注意 `cacheDateTime` 欄位

## 常用工作流

### 查物料價目（SD080）
`GET /api/Price/GetSalesPriceList?SearchKey=&Material=<18位>&Limit=&PreSalesOff=&Plants=<工廠>` → `data[].priceinfo[]`（sapMAP/sapCOST/sjCost/kfCost、庫存、ATR、採購備註）

### 查客戶出貨（SD170，品類聚合）
`POST /api/ShipmentHistory/GetVw169HistoryAllCustomerAndLevelExcelBySql`，Body `{"CustomerIds":["<10位>"],"PageIndex":0,"PageSize":500}` → `list[]`，按 `levelLastShipmentDate` 篩選日期

### 查客戶某日物料級出貨明細（兩步，無單一接口）
1. `POST /api/SD290_Credit/GetCustomerInvoice`：`{"CustomerId":"<10位>","StartDate","EndDate","ItemType":"INVOICE/INVOICE記錄"}` → 取發票號 `invoicesNum`（ItemType 必填，可選 `STM`/`付款記錄`/`INVOICE/INVOICE記錄`）
2. `GET /api/Sd170ShipmentHistory/GetHistoryShipmentsRecord?Fkdat=<yyyy-MM-dd>&Vbeln=<發票號>&Posnr=<行號>` 逐行取（行號跳號，見規則 3）→ `resultData` 含 `matnr`/`maktx`/`price`/`fkimg`/`weight`/`iamt`

## 完整端點參考

全部 40+ 端點的參數、回應結構、調用示例見 `references/api_reference.md`。需要某端點的詳細信息時用 Grep 搜端點路徑（如 `GetSalesPriceList`）定位章節。

## 注意事項

- 這是**生產環境** API，寫操作端點（InsertOrUpdate/Save/Upload 類）調用前必須向用戶確認
- 已知安全觀察：`LoginSpecial` 超管後門、JWT 有效期長、exe.config 含 FTP 明文密碼——不要在報告外洩漏這些細節
- 客戶端 ClickOnce 部署源：`\\aliyun-share.sjfood.us\Software\SJFOOD_3_0_PRD\`
