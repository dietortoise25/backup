# -*- coding: utf-8 -*-
"""SJFOOD 3.0 API 客戶端（sj-skill）

用法：
    python sjfood_client.py login <賬號> <密碼>
    python sjfood_client.py price --material 40052897 --plant 1800
    python sjfood_client.py price --search 殼蝦 --limit 10
    python sjfood_client.py shipments --customer 108716 --date 2026-08-04
    python sjfood_client.py invoices --customer 108716 --start 2026-08-04 --end 2026-08-04
    python sjfood_client.py invoice-items --vbeln 0500164755 --fkdat 2026-08-04

憑據優先順序：命令行 --user/--pass > 環境變量 SJFOOD_USER/SJFOOD_PASS。
Token 緩存於 %TEMP%/sjfood_token.json，有效期內（約3~4天）自動復用。

注意：
- Material 自動補零至 18 位；CustomerId 自動補零至 10 位
- 回應 JSON 欄位為小寫（camelCase），客戶端已統一處理
- 發票行號會跳號，invoice-items 已內建容忍邏輯（連續 8 空號停止）
"""
import argparse
import json
import os
import sys
import tempfile
from datetime import datetime, timezone

try:
    import requests
except ImportError:
    sys.exit("缺少 requests，請先 pip install requests")

BASE = "https://api-sjfood3.sjfood.us"
TOKEN_CACHE = os.path.join(tempfile.gettempdir(), "sjfood_token.json")


def ci(d):
    """dict 的 key 轉小寫"""
    return {k.lower(): v for k, v in d.items()} if isinstance(d, dict) else d


class SJFoodClient:
    def __init__(self, username=None, password=None):
        self.s = requests.Session()
        self.s.headers["Accept"] = "application/json"
        self.user = username or os.environ.get("SJFOOD_USER")
        self.pwd = password or os.environ.get("SJFOOD_PASS")
        self.token = self._load_cached_token()
        if not self.token:
            self.login()

    def _load_cached_token(self):
        try:
            with open(TOKEN_CACHE, encoding="utf-8") as f:
                c = json.load(f)
            exp = datetime.fromisoformat(c["expiration"].replace("Z", "+00:00"))
            if exp > datetime.now(timezone.utc) and c.get("user") == self.user:
                return c["token"]
        except Exception:
            pass
        return None

    def login(self):
        if not self.user or not self.pwd:
            sys.exit("缺少賬號密碼：傳參 --user/--pass 或設環境變量 SJFOOD_USER/SJFOOD_PASS")
        r = self.s.post(BASE + "/api/De020_Login/Login",
                        json={"username": self.user, "password": self.pwd, "Comments": ""},
                        timeout=30)
        r.raise_for_status()
        d = r.json()
        self.token = d["token"]
        with open(TOKEN_CACHE, "w", encoding="utf-8") as f:
            json.dump({"token": self.token, "expiration": d.get("expiration"),
                       "user": self.user}, f)
        return self.token

    @property
    def h(self):
        return {"Authorization": "Bearer " + self.token}

    # ---------- SD400 客戶 ----------
    def get_customers_by_sales(self, sales):
        """按銷售取客戶列表。sales 為用戶名列表如 ['HEBE.ZHENG']。
        主管場景：UI 先用 vw_staff_leader_B 查下屬再傳入；API 層直接傳用戶名即可。
        返回欄位含 kunnr/name1/name2/city/vkgrp(銷售組)/lastinvdate 等"""
        r = self.s.post(BASE + "/api/CustomerInfo/GetCustomersBySales",
                        json={"Sales": sales}, headers=self.h, timeout=60)
        r.raise_for_status()
        return ci(r.json()).get("customers") or []

    # ---------- SD080 價錢表 ----------
    def get_price_list(self, material="", search_key="", plants=None, limit=20):
        """查銷售價目。material 自動補零至18位；plants 為工廠列表如 ['1800']"""
        if material and material.isdigit() and len(material) < 18:
            material = material.zfill(18)
        params = [("SearchKey", search_key), ("Material", material),
                  ("Limit", limit), ("PreSalesOff", "false")]
        for p in (plants or []):
            params.append(("Plants", p))
        r = self.s.get(BASE + "/api/Price/GetSalesPriceList", params=params,
                       headers=self.h, timeout=60)
        r.raise_for_status()
        return ci(r.json()).get("data") or []

    # ---------- SD170 出貨記錄 ----------
    def get_customer_shipments(self, customer_id, page_size=500):
        """客戶品類級出貨聚合（vw_169）。customer_id 自動補零至10位"""
        cid = customer_id.zfill(10) if customer_id.isdigit() else customer_id
        r = self.s.post(BASE + "/api/ShipmentHistory/GetVw169HistoryAllCustomerAndLevelExcelBySql",
                        json={"CustomerIds": [cid], "PageIndex": 0, "PageSize": page_size},
                        headers=self.h, timeout=120)
        r.raise_for_status()
        return ci(r.json()).get("list") or []

    def get_shipments_on_date(self, customer_id, date_str):
        """客戶某日有出貨的品類（按 levelLastShipmentDate 篩選）"""
        rows = self.get_customer_shipments(customer_id)
        return [x for x in rows if str(x.get("levelLastShipmentDate") or "").startswith(date_str)]

    # ---------- 發票 ----------
    def get_customer_invoices(self, customer_id, start, end,
                              item_type="INVOICE/INVOICE記錄"):
        """客戶發票清單。item_type 必填：STM / 付款記錄 / INVOICE/INVOICE記錄"""
        cid = customer_id.zfill(10) if customer_id.isdigit() else customer_id
        r = self.s.post(BASE + "/api/SD290_Credit/GetCustomerInvoice",
                        json={"CustomerId": cid,
                              "StartDate": f"{start}T00:00:00",
                              "EndDate": f"{end}T23:59:59",
                              "ItemType": item_type},
                        headers=self.h, timeout=60)
        r.raise_for_status()
        return ci(r.json())

    def get_invoice_items(self, vbeln, fkdat, max_gap=8):
        """發票行項目明細（物料/名稱/單價/數量/金額）。
        行號跳號：連續 max_gap 個空號才停止。"""
        items, miss = [], 0
        for i in range(10, 1000, 10):
            r = self.s.get(BASE + "/api/Sd170ShipmentHistory/GetHistoryShipmentsRecord",
                           params={"Fkdat": fkdat, "Vbeln": vbeln,
                                   "Posnr": f"{i:06d}"},
                           headers=self.h, timeout=30)
            rd = r.json().get("resultData")
            if rd:
                items.append(rd)
                miss = 0
            else:
                miss += 1
                if miss >= max_gap:
                    break
        return items


def main():
    ap = argparse.ArgumentParser(description="SJFOOD 3.0 API 客戶端")
    ap.add_argument("--user"); ap.add_argument("--pwd")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("login", help="登入並緩存 token")
    p.add_argument("username"); p.add_argument("password")

    p = sub.add_parser("customers", help="按銷售取客戶列表")
    p.add_argument("--sales", action="append", required=True,
                   help="銷售用戶名，可重複傳多個")

    p = sub.add_parser("price", help="查銷售價目")
    p.add_argument("--material", default=""); p.add_argument("--search", default="")
    p.add_argument("--plant", action="append", default=[]); p.add_argument("--limit", type=int, default=20)

    p = sub.add_parser("shipments", help="客戶出貨品類（可按日期篩選）")
    p.add_argument("--customer", required=True); p.add_argument("--date", default=None)

    p = sub.add_parser("invoices", help="客戶發票清單")
    p.add_argument("--customer", required=True)
    p.add_argument("--start", required=True); p.add_argument("--end", required=True)

    p = sub.add_parser("invoice-items", help="發票行項目明細")
    p.add_argument("--vbeln", required=True); p.add_argument("--fkdat", required=True)

    args = ap.parse_args()

    if args.cmd == "login":
        os.environ["SJFOOD_USER"] = args.username
        os.environ["SJFOOD_PASS"] = args.password
        c = SJFoodClient(args.username, args.password)
        print("登入成功，token 已緩存")
        return

    c = SJFoodClient(args.user, args.pwd)

    if args.cmd == "price":
        data = c.get_price_list(args.material, args.search, args.plant, args.limit)
        print(json.dumps(data, ensure_ascii=False, indent=2))
    elif args.cmd == "customers":
        print(json.dumps(c.get_customers_by_sales(args.sales),
                         ensure_ascii=False, indent=2))
    elif args.cmd == "shipments":
        data = (c.get_shipments_on_date(args.customer, args.date) if args.date
                else c.get_customer_shipments(args.customer))
        print(json.dumps(data, ensure_ascii=False, indent=2))
    elif args.cmd == "invoices":
        print(json.dumps(c.get_customer_invoices(args.customer, args.start, args.end),
                         ensure_ascii=False, indent=2))
    elif args.cmd == "invoice-items":
        items = c.get_invoice_items(args.vbeln, args.fkdat)
        total = sum(x.get("iamt") or 0 for x in items)
        print(json.dumps(items, ensure_ascii=False, indent=2))
        print(f"共 {len(items)} 行，合計 ${total:.2f}", file=sys.stderr)


if __name__ == "__main__":
    main()
